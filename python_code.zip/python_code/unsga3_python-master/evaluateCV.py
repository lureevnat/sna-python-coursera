def evaluateCV(pop_cons):

    g = pop_cons;

    for i in range(0,pop_cons.shape[0]):
        for j in range(0,pop_cons.shape[1]):
            if g[i][j]<0:
                g[i][j] = 0;

    cv = g.sum(1)
    return cv
