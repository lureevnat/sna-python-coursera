import math
import numpy as np
import sys

def range1(start,end,step=1):
    
    return range(start,end+1,step)
    
def high_fidelity_evaluation(opt,x):
    problem = opt["objfunction"].lower();
    g = np.array([])
    
    if list(problem) ==  list('c2dtlz2'):
            n=x.shape[0];#to match matlab indexing
            nfunc = opt["M"];
            k = n - nfunc + 1;
            g = 0;
            for i in range(nfunc-1,n):
                g = g +  (x[i]-0.5)**2;
            f = np.zeros((1,nfunc));#extra to matlab
            f = f.reshape(f.shape[1]);#extra to matlab
            fit = np.zeros((1,nfunc));
            fit = fit.reshape(fit.shape[1])
            
            
            for i in range1(1,nfunc):
                h = 1 + g;
            
                for j in range1(1,nfunc - i):
                    h =h * math.cos( x[j-1] * 3.141592654 / 2);
                if (i > 1):
                    h = h*math.sin( x[(nfunc - i + 1-1)] * 3.141592654 / 2);
                fit[i-1] = h;

            f[0] = fit[0];
            f[1] = fit[1];
            f[2] = fit[2];

            #now calculate constraints
            
            if(nfunc>3):
                r = 0.5;
            else:
                r = 0.4;
            v1 = sys.float_info.max;
            v2 = 0.0;
            for i in range1(1, nfunc):
                sum1 = (f[i-1]-1.0)** 2.0;
                for j in range1(1, nfunc):
                    if i != j:
                        sum1 = sum1 + (f[j-1]** 2.0);
                v1 = min(v1, sum1 - (r**2.0));
                v2 = v2 + (f[i-1] -  (1.0 / math.sqrt(nfunc)))** 2.0;
            
            

            c = min(v1, v2 - (r** 2.0));
            g = np.array([0.]);
            if c<=0:
                g[0]=c
            else:
                g[0]=c

    else:
            print('Function defition is not found inside high fidelity evaluation');

    #for unconstraint problem
    if opt["C"]==0:
       g = np.array([]);
    return [f,g];