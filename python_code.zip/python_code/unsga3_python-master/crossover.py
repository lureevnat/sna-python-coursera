import sbx


def crossover(opt):
    if opt["crossoverOption"] == 1:
            [opt["popChild"], opt["nrealcross"]] = sbx.sbx(opt["popChild"], opt["pcross"], opt["nrealcross"], opt["eta_c"], opt["bound"][0][:], opt["bound"][1][:], opt["Epsilon"]);
    else:

            [opt["popChild"], opt["nrealcross"]] = sbx.sbx(opt["popChild"], opt["pcross"], opt["nrealcross"], opt["eta_c"], opt["bound"][0][:], opt["bound"][1][:], opt["Epsilon"]);
    return opt
