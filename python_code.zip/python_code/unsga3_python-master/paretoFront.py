import  bos
import numpy as np

def paretoFront(FeasibleObj):
    [R,_] = bos.bos(FeasibleObj);
    R = np.array(R)
    index = np.where(R==0);
    return index;
