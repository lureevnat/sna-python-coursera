import numpy as np
import bos
import math
import cell
import pdb

def nsga3_selection(opt):

    [n, _] = opt["totalpopObj"].shape;
    opt["R"] = np.zeros((opt["totalpopObj"].shape[0],1));

    selectedPopIndex = [];
    index = opt["totalpopCV"]<=0;
    FeasiblePopIndex = np.where(index == 1)[0];
    #FeasiblePopIndex = np.transpose([FeasiblePopIndex])
    InfeasiblePopIndex = np.where(index == 0)[0];
    #InfeasiblePopIndex = np.transpose([InfeasiblePopIndex ])
    #----------------------------------------------------------------------
    #---------Find Non-dominated Sorting of Feasible Solutions If exists---
    #----------------------------------------------------------------------


    F = cell.cell(n,1)
    opt["R"] = np.zeros((n,1));
    if FeasiblePopIndex.size:

        [R,_] = bos.bos(opt["totalpopObj"][FeasiblePopIndex][:]);

        for i in range(0,FeasiblePopIndex.shape[0]):
            F[R[i]] = F[R[i]] + [FeasiblePopIndex[i]];


    #----------------------------------------------------------------------
    #--If Less #Feasible <N, then we need sort infeasibles to select-------
    #----------------------Don't do niching here---------------------------
    #----------------------------------------------------------------------

    #%% Haitham - Start
    opt["pop2Dir"] = np.zeros((opt["N"], 1));
    opt["pop2DirDistances"] = np.zeros((opt["N"], 1));
    opt["associationsReady"] = False;
    idx = 0;
    #% Haitham
    #tanveer-start
    FeasiblePopIndex = np.transpose([FeasiblePopIndex])
    InfeasiblePopIndex = np.transpose([InfeasiblePopIndex ])
    #tanveer-end
    
    if FeasiblePopIndex.shape[0]<opt["N"]:

        #-------------Pick all feasible solutions--------------------------
        selectedPopIndex = np.transpose(FeasiblePopIndex);

        #--------------Rank the Infeasible Solutions-----------------------

        if InfeasiblePopIndex.size:

            CV = opt["totalpopCV"][InfeasiblePopIndex];
            CV = CV.reshape(CV.shape[0],1)
            #[_,index] = np.sort(CV);#ascending order
            index = np.argsort(CV,axis=0)

            for i in range(0, index.shape[0]):
                selectedPopIndex = np.append(selectedPopIndex[0], InfeasiblePopIndex[index[i][0]][0]);
                selectedPopIndex = np.transpose(np.transpose([selectedPopIndex]))
                if selectedPopIndex.shape[1] >= opt["N"]:
                    break;

    #----------------------------------------------------------------------
    #--If there are more #Feasibles than we need to select, Do Niching-----
    #----------------------------------------------------------------------

    else:

        #%% Haitham - Start
        opt["associationsReady"] = True;
        # Haitham - End

        #------------------Find Last Front---------------------------------

        count = np.zeros((n,1));
        for i in range(0,n):
            count[i] = len(F[i]);

        cd = np.cumsum(count,axis=0);
        p1 = np.transpose([np.where(opt["N"]<cd)[0]]);
        lastfront = p1[0][0];

        #-----------Select upto the front before last front----------------
        if lastfront ==1:
            selectedPopIndex =selectedPopIndex + F[0]
        else:
            for i in range(0,lastfront-1):
                selectedPopIndex =selectedPopIndex + F[i]

        selectedPopIndex = np.transpose(np.transpose([np.array(selectedPopIndex,dtype="int64")]))
        #do a check in to see if N reached

        lastPopIndex = F[lastfront];
        lastPopIndex = np.transpose(np.transpose([lastPopIndex]))
        combinedObj = np.vstack((opt["totalpopObj"][selectedPopIndex[0],:], opt["totalpopObj"][lastPopIndex[0],:]))
        combinePopIndex = np.hstack((selectedPopIndex[0], lastPopIndex[0]));
        combinePopIndex = np.array([combinePopIndex])
        #------------------------------------------------------------------
        #---------------------------FIND INTERCEPT-------------------------
        #------------------------------------------------------------------

        z = np.array([np.amin(combinedObj,axis=0)]);#find the population minimum
        TranslatedObj = combinedObj - np.tile(z, (combinedObj.shape[0], 1));#recalculate objective according to z

        ASFLines = np.identity(opt["M"]);#ASF direction inclined along each objective
        S = np.zeros((opt["M"], opt["M"]));#To collect the intercept

        for i in range(0,opt["M"]):
            w = np.array(ASFLines[i][:]);
            for temp in range(0,opt["M"]):
                if(temp!=i):
                    w[temp] = 1e-16
            w = np.divide(w,np.linalg.norm(w));
            #finding ASF values with a direction inclined in an objective
            #index = np.argmin(np.max(np.divide(TranslatedObj,np.tile(w.reshape(1,w.shape[0]),(TranslatedObj.shape[0],1))),[],2)); 
            
            
            #tanveer
            index = np.tile(w.reshape(1,w.shape[0]),(TranslatedObj.shape[0],1))
            index = np.divide(TranslatedObj,index)
            index = np.transpose(np.array([index.max(1)]))
            index = np.argmin(index)
            
     
            S[i][:] = np.array([TranslatedObj[index][:]]); #choise the element with smallest asf w.r.t. ASFLines(i,:)

        #----Check if M points doesn't make M-simplex----------------------
        #----It can also happen when size(lastPopIndex,2)<opt.M------------

        if np.linalg.det(S)<1e-16:
            A = np.max(TranslatedObj,[], 1);
        else:
            b = np.ones((opt["M"],1));
            A = np.linalg.solve(S,b);
            A = np.divide(1,A);
            A = np.transpose(A);

#             if opt["M"]==3: # check intercept
#                 hold all;
#                 xlabel('x')
#                 ylabel('y')
#                 zlabel('z')
#                 box on
#                 grid on
#                 hold on
#                 Intercept = [A(1) 0 0;
#                             0 A(2) 0;
#                             0 0 A(3)];
#                 fill3(Intercept(:,1),Intercept(:,2),Intercept(:,3),'c');
#                 scatter3(S(:,1), S(:,2), S(:,3),'*');
#             end

        #---------------Plot to see if intercept is correct----------------



        #------------------NORMALIZE WITH INTERCEPT------------------------

        NormalizedObj = np.divide(TranslatedObj,np.tile(A,(TranslatedObj.shape[0],1)));

        #------------------------------------------------------------------
        #-------------------ASSOCIATION------------------------------------
        #------------------------------------------------------------------

        #------------------------------------------------------------------
        #-----For Each Direction select nearest solution for last front----
        #-----For Two cases: Selected fronts, and Last front---------------
        #------------------------------------------------------------------
        #should have been same for all cases

        Count = np.zeros((opt["numdir"], 1));

        #----------------for selected indices------------------------------

        tempPopDir = np.zeros((opt["totalpopObj"].shape[0], 1));#for each solution save direction
        distance = np.zeros((opt["totalpopObj"].shape[0], 1));#for each solution save distance of that direction
        distance[0:] = math.inf;

        for i in range(0,selectedPopIndex.shape[0]):
            if selectedPopIndex.shape[1] == 0:
                continue
                
            s = selectedPopIndex[0][i];
            obj = NormalizedObj[np.where(combinePopIndex==s)[0],:];

            for j in range(0,opt["numdir"]):
                w = opt["dirs"][j,:];
                w = np.transpose(np.transpose([w]))
                d = np.linalg.norm(obj-((w*np.transpose(obj))*w)/(np.linalg.norm(w)*np.linalg.norm(w)));#remove one '

                if d < distance[s][0]:
                    tempPopDir[s] = j;
                    distance[s] = d;

            Count[int(tempPopDir[s][0])] = Count[int(tempPopDir[s][0])]+1;

            #%% Haitham - Start
            opt["pop2Dir"][idx] = tempPopDir[s][0];
            opt["pop2DirDistances"][idx] = distance[s][0];
            idx = idx + 1;
            # Haitham - End

        #----------------for last front indices----------------------------
        DirLast = cell.cell(opt["numdir"],1);#collect the solutions those prefer this direction
        DirLastDist = cell.cell(opt["numdir"],1);#collect the distances
        tempPopDir = np.zeros((opt["totalpopObj"].shape[0], 1));#for each solution save direction
        distance = np.zeros((opt["totalpopObj"].shape[0], 1));#for each solution save distance of that direction
        distance[0:] = math.inf;

        for i in range(0,lastPopIndex.shape[1]):
            s = lastPopIndex[0][i];
            obj = NormalizedObj[np.where(combinePopIndex==s)[1][0]][:];#take normalized obj
            obj = np.transpose(np.transpose([obj]))
            for j in range(0,opt["numdir"]):
                w = opt["dirs"][j,:];
                d = np.linalg.norm(obj-((w*np.transpose(obj))*w)/(np.linalg.norm(w)*np.linalg.norm(w)));#remove one '
                if d < distance[s][0]:
                    tempPopDir[s] = j;
                    distance[s] = d;


            DirLast[int(tempPopDir[int(s)])] = DirLast[int(tempPopDir[int(s)])]+ [s];
            DirLastDist[int(tempPopDir[s])] = DirLastDist[int(tempPopDir[int(s)])] + distance[s].tolist();

        #-------------------NICHING PRESERVATION---------------------------

        for i in range(0,opt["numdir"]):
            I = np.argsort(DirLastDist[i]).tolist();
            DirLast[i] = [DirLast[i][j] for j in I] ;

        while selectedPopIndex.shape[1]<opt["N"] and idx<opt["pop2Dir"].shape[0]:

            [p_j, j]=[np.min(Count),np.argmin(Count)]

            if len(DirLast[j])==0:
                Count[j][0]=math.inf; #excluded for further consideration

            elif p_j==0:
                selectedPopIndex = np.hstack((selectedPopIndex[0], DirLast[j][0]));#choose the first
                selectedPopIndex = np.transpose(np.transpose([selectedPopIndex]))
                #%% Haitham - Start
                opt["pop2Dir"][idx] = DirLast[j][0];
                opt["pop2DirDistances"][idx] = DirLastDist[j][0];
                idx = idx + 1;
                #% Haitham - End

                Count[j] = Count[j]+1;
                del DirLast[j][0];

            else: #% when p_j>=1
                index = np.random.randint(len(DirLast[j])); #chose randomly
                selectedPopIndex = np.hstack((selectedPopIndex[0], DirLast[j][index]));
                selectedPopIndex = np.transpose(np.transpose([selectedPopIndex]))
                #%% Haitham - Start
                opt["pop2Dir"][idx][0] = DirLast[j][index]
                opt["pop2DirDistances"][idx][0] = DirLastDist[j][index];
                idx = idx + 1;
                    
                #% Haitham - End
                
                del DirLast[j][index] 
                Count[j] = Count[j]+1;

    #end#if size(FeasiblePopIndex,1)<opt.N

    #---------------Select for Next Generation-----------------------------

    opt["pop"] =  opt["totalpop"][selectedPopIndex][:][0];
    opt["popObj"] = opt["totalpopObj"][selectedPopIndex][:][0];
    opt["popCV"] = opt["totalpopCV"][selectedPopIndex][:][0];
    opt["popCons"] = opt["totalpopCons"][selectedPopIndex][:][0];
    return opt;
