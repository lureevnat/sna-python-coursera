#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Aug  4 17:02:57 2018

@author: coea
"""


def shape(a):
    return(len(a),len(a[0]))
def cell(a,b):
    if b == 1:
        return [[]]*a
    

