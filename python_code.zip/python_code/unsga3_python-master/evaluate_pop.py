import numpy as np
import high_fidelity_evaluation


def evaluate_pop(opt, pop):

    popObj = np.zeros((pop.shape[0],opt["M"]));
    if opt["C"]>0:
        popCons = np.zeros((pop.shape[0],opt["C"]));
    else:
        popCons = np.zeros((pop.shape[0], 1));
    sz = pop.shape[0];
    
    for i in range(0,sz):

        [f, g] = high_fidelity_evaluation.high_fidelity_evaluation(opt, pop[i][:]);
        popObj[i][0:opt["M"]] = f;
        if opt["C"]>0:
            popCons[i][:] = g;
        else:
            popCons[i][0] = 0;
    return [popObj, popCons]; 