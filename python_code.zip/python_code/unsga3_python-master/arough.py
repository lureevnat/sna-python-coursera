import numpy as np
import high_fidelity_evaluation

opt = {}
opt["M"] = 3
opt["C"] = 1
opt["objfunction"] = "c2dtlz2"

x = np.genfromtxt("data.csv",delimiter=",")
[a,b] = high_fidelity_evaluation.high_fidelity_evaluation(opt,x[2])
print(a)
print(b)